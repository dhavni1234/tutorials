//
//  CustomUITextField.h


//

#import <UIKit/UIKit.h>

@class CustomUITextField;

IB_DESIGNABLE

@protocol CustomUITextFieldDelegate <NSObject>

- (void)didPressedDoneButton:(CustomUITextField *)textField;

@end

@interface CustomUITextField : UITextField

@property(nonatomic) IBInspectable NSInteger heightBottomLine;
@property(nonatomic) IBInspectable NSInteger offsetBottomLine;
@property(nonatomic) IBInspectable NSInteger cornerRadious;
@property(nonatomic) IBInspectable NSInteger borderWidth;
@property(nonatomic,strong) IBInspectable UIColor *borderColor;
@property(nonatomic,strong) IBInspectable UIColor *colorBottomLine;
@property(nonatomic,strong) IBInspectable UIColor *activeColorBottomLine;
@property(nonatomic,strong) IBInspectable UIColor *colorPlaceholder;
@property(nonatomic,strong) IBInspectable UIImage *leftIcon;
@property(nonatomic,strong) IBInspectable UIImage *rightIcon;
@property (nonatomic, retain) UIDatePicker *datePicker;
@property(nonatomic) id <CustomUITextFieldDelegate> txtFieldDelegate;

+ (CustomUITextField *)activeTextField;


@end
