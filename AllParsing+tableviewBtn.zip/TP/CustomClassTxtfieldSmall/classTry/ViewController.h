//
//  ViewController.h
//  classTry
//

//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIView *txtFieldTesting;

@end

