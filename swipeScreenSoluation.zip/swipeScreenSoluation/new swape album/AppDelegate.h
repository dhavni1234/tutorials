//
//  AppDelegate.h
//  new swape album
//
//  Created by Ashish Sharma on 04/11/16.
//  Copyright © 2016 Ashish Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

