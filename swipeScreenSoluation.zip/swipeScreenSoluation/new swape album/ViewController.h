//
//  ViewController.h
//  new swape album
//
//  Created by Ashish Sharma on 04/11/16.
//  Copyright © 2016 Ashish Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *ImageView;
@property (weak, nonatomic) IBOutlet UITextView *TextView;
- (IBAction)PreviousButton:(id)sender;
- (IBAction)NextBUtton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *previousButton;
@property (weak, nonatomic) IBOutlet UIButton *NextButton;

@end

