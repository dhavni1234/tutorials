//
//  ViewController.m
//  new swape album
//
//  Created by Ashish Sharma on 04/11/16.
//  Copyright © 2016 Ashish Sharma. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    //NSArray *Image;
    NSArray *text;
    int counter;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    counter = 0;
    text = [[NSArray alloc]initWithObjects:@"1.jpg",@"2.jpg",@"3.jpg",@"4.jpg", nil];
    self.ImageView.image = [UIImage imageNamed:text[0]];
    self.TextView.text = text[0];
    [self.previousButton setHidden:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)PreviousButton:(id)sender {
    counter -= 1;
    if(counter <= text.count){
        self.ImageView.image = [UIImage imageNamed:text[counter]];
        self.TextView.text = text[counter];
        if (counter < 3){
            [self.NextButton setHidden:NO];
        }
        if(counter == 0){
            [self.previousButton setHidden:YES];
        }
    }

}

- (IBAction)NextBUtton:(id)sender {
    counter += 1;
    if(counter <= text.count){
    self.ImageView.image = [UIImage imageNamed:text[counter]];
        self.TextView.text = text[counter];
        if (counter > 0){
            [self.previousButton setHidden:NO];
        }
        if(counter == 3){
            [self.NextButton setHidden:YES];
        }
    }
    
}
@end
