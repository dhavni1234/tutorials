//
//  userInfo1Controller.h
//  menuButtonTry
//


#import <UIKit/UIKit.h>

@interface userInfo1Controller : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnGetBackOutlet;
- (IBAction)btnGetBack:(id)sender;
@property NSDictionary *userInfoDictOnController2;
@property (weak, nonatomic) IBOutlet UILabel *lblFullName;
@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UILabel *lblMob;
@end
