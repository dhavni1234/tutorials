//
//  userInfo2Controller.h
//  menuButtonTry
//

#import <UIKit/UIKit.h>

@interface userInfo2Controller : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnGetBack;
- (IBAction)btnGetBack:(id)sender;
@property NSDictionary *userInfoDictOnController3;
@property (weak, nonatomic) IBOutlet UILabel *lblFullName;
@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UILabel *lblMob;
@end
