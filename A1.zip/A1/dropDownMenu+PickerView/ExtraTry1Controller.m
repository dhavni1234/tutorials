//
//  ExtraTry1Controller.m
//  dropDownButtonTry
//
//  Created by Raghu Bansal on 11/17/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "ExtraTry1Controller.h"

@interface ExtraTry1Controller ()

@end

@implementation ExtraTry1Controller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
