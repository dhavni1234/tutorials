//
//  MenuCell.h
//  menuButtonTry
//
//  Created by Raghu Bansal on 10/25/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UIButton *btndetailOutlet;
- (IBAction)btndetail:(id)sender;

@end
