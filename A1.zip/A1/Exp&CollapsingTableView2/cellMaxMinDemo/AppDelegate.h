//
//  AppDelegate.h
//  cellMaxMinDemo
//
//  Created by Sugartin on 20/11/15.
//  Copyright © 2015 Sugartin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

