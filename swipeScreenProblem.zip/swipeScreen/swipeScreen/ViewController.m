//
//  ViewController.m
//  swipeScreen
//
//  Created by Raghu Bansal on 11/4/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *arrayImages;
    NSArray *arrayImageDetailText;
    int Counter;
}


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    Counter = 0;
    self.btnPreviousOutlet.hidden = YES;

    arrayImages = [[NSArray alloc]initWithObjects:@"page1.png",@"page2.png",@"page3.png",@"page4.png", nil];
    self.imageView.image = [UIImage imageNamed:@"page1.png"];
    //arrayImages = @[@"page1.png", @"page2.png", @"page3.png", @"page4.png"];
    arrayImageDetailText = [[NSArray alloc]initWithObjects:@"Image 1",@"Image 2",@"Image 3",@"Image 4", nil];
    self.txtView.text = [arrayImageDetailText objectAtIndex:0];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnNextImage:(id)sender {
    if (Counter >= arrayImages.count) {
        //        [self.imageView setImage:[UIImage imageNamed:[arrayImages objectAtIndex:Counter]]];
        //        self.txtView.text = [arrayImageDetailText objectAtIndex:Counter];
        self.btnNextOutlet.hidden = YES;
    }
    Counter += 1;
    if (Counter > 0) {
        self.btnPreviousOutlet.hidden = NO;
        NSLog(@"Condition Check For Counter:%d",Counter);
        [self.imageView setImage:[UIImage imageNamed:[arrayImages objectAtIndex:Counter]]];
        self.txtView.text = [arrayImageDetailText objectAtIndex:Counter];
        NSLog(@"Counter Value:%d",Counter);

}
    
    
   
    
}

- (IBAction)btnPreviousImage:(id)sender {
    Counter -= 1;
    if (Counter >= arrayImages.count) {
        self.btnNextOutlet.hidden = YES;
        
    }
    if (Counter<=arrayImages.count) {
        [self.imageView setImage:[UIImage imageNamed:[arrayImages objectAtIndex:Counter]]];
        self.txtView.text = [arrayImageDetailText objectAtIndex:Counter];
        
    }
   
   
    
}


@end
