//
//  ViewController.h
//  swipeScreen
//
//  Created by Raghu Bansal on 11/4/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)btnPreviousImage:(id)sender;
- (IBAction)btnNextImage:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UITextView *txtView;
@property (weak, nonatomic) IBOutlet UIButton *btnPreviousOutlet;
@property (weak, nonatomic) IBOutlet UIButton *btnNextOutlet;



@end

