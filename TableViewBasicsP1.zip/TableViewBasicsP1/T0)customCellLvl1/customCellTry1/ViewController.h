//
//  ViewController.h
//  customCellTry1
//


#import <UIKit/UIKit.h>
#import "customCellTableViewCell.h"

@interface ViewController : UIViewController <UITableViewDataSource,UITableViewDelegate>



@end

