//
//  TableViewController.h
//  TaskTableViewBTnDataTrf
//


#import <UIKit/UIKit.h>
#import "TableViewCell.h"

@interface TableViewController : UITableViewController<UITableViewDelegate,UITableViewDataSource>



@end
