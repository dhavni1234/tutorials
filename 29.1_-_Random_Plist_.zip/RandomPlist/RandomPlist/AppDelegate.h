//
//  AppDelegate.h
//  RandomPlist
//
//  Created by Aaron on 01/07/2015.
//  Copyright © 2015 GeekyLemonDevelopment. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

