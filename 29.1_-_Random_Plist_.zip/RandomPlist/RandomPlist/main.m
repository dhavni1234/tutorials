//
//  main.m
//  RandomPlist
//
//  Created by Aaron on 01/07/2015.
//  Copyright © 2015 GeekyLemonDevelopment. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
