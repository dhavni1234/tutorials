//
//  ViewController.h
//  RandomPlist
//
//  Created by Aaron on 01/07/2015.
//  Copyright © 2015 GeekyLemonDevelopment. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *Label;
- (IBAction)RandimPlist:(id)sender;

@end

