//
//  ViewController.m
//  DropDown
//
//  Created by cibl-tcl on 8/17/15.
//  Copyright (c) 2015 cibl-tcl. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.data = [[NSArray alloc]initWithObjects:@"Value1",@"Value2",@"Value3",@"Value4",@"Value5", nil];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [self.data count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        
    }
    
    
    cell.textLabel.text = [self.data objectAtIndex:indexPath.row] ;
    
    //cell.textLabel.font = [UIFont systemFontOfSize:11.0];
    

    return cell;
    
    
    
}





- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    [self.btnOutlet setTitle:cell.textLabel.text forState:UIControlStateNormal];
    
    self.tableView.hidden = YES;
    
    
    
}


- (IBAction)btnAction:(id)sender {
    
    if (self.tableView.hidden == YES) {
        self.tableView.hidden = NO;
    }
    
    else
        self.tableView.hidden = YES;
    
    
}
@end
