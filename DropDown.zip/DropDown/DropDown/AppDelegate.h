//
//  AppDelegate.h
//  DropDown
//
//  Created by cibl-tcl on 8/17/15.
//  Copyright (c) 2015 cibl-tcl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

