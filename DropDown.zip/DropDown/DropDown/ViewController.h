//
//  ViewController.h
//  DropDown
//
//  Created by cibl-tcl on 8/17/15.
//  Copyright (c) 2015 cibl-tcl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@property (weak, nonatomic) IBOutlet UIButton *btnOutlet;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(strong , nonatomic) NSArray *data;

- (IBAction)btnAction:(id)sender;

@end

