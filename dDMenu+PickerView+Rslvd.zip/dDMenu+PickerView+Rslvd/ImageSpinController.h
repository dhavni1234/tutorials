//
//  ImageSpinController.h
//  dropDownButtonTry
//

#import <UIKit/UIKit.h>

@interface ImageSpinController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageSpin1;
@property (weak, nonatomic) IBOutlet UIImageView *imageSpin2;

@end
