//
//  ChooseController.h
//  dropDownButtonTry
//


#import <UIKit/UIKit.h>

@interface ChooseController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnTestOutlet;

@end
