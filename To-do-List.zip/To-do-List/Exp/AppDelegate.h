//
//  AppDelegate.h
//  Exp
//
//  Created by TechReviews on 4/29/16.
//  Copyright (c) 2016 TechReviews. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

