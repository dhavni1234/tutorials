//
//  DetailViewController.m
//  Json
//
//  Created by Raghu Bansal on 9/27/16.
//  Copyright © 2016 RWS. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //For image view controller circular.
     self.imageView.layer.cornerRadius = self.imageView.frame.size.height /2;
     self.imageView.layer.masksToBounds = YES;
     self.imageView.layer.borderWidth = 0;
    
    self.btnUpdateProfileOutlet.layer.cornerRadius = self.btnUpdateProfileOutlet.frame.size.height /2;
    self.btnUpdateProfileOutlet.layer.masksToBounds = YES;
    self.btnUpdateProfileOutlet.layer.borderWidth = 0;
    
    
    //Notification data received.
    [[NSNotificationCenter defaultCenter]
     addObserver:self selector:@selector(triggerAction:) name:@"NotificationMessageEvent" object:nil];
    
}

-(void) triggerAction:(NSNotification *) notification
{
    if ([notification.object isKindOfClass:[NSArray class]])
    {
        NSArray *arr = [notification object]; // here array is taken else either be dictionary acc to req.
        NSString *fullname = [arr[0] valueForKey:@"name"]; // here keys are as per the webservices.
        NSString *userType = [arr[0] valueForKey:@"user_type"];
        NSString *licenseNumber = [arr[0] valueForKey:@"license_number"];
        NSString *email = [arr[0] valueForKey:@"email"];
        NSString *age = [arr[0] valueForKey:@"age"];
        NSString *sex = [arr[0] valueForKey:@"sex"];
        // To show image.
        NSURL *imageURL = [NSURL URLWithString:[arr[0] valueForKey:@"profile_image"]];
        NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
        UIImage *imageLoad = [[UIImage alloc] initWithData:imageData];
      
        
        self.lblFullName.text = fullname; // assigning values to the respective labels.
        self.lblFirstName.text = userType;
        self.lblLastName.text = licenseNumber;
        self.lblEmail.text = email;
        self.lblAge.text = age;
        self.lblSex.text =  sex;
        self.imageView.image = imageLoad;
        
        /*
         NSURL *imageURL = [NSURL URLWithString:[appsdict objectForKey:@"image"]];
         NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
         UIImage *imageLoad = [[UIImage alloc] initWithData:imageData];
         cell.imageView.image = imageLoad;
         */
    }
    else
    {
        NSLog(@"Error, object not recognised.");
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnUpdateProfile:(id)sender {
}
@end
