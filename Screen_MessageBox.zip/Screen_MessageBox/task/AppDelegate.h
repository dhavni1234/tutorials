//
//  AppDelegate.h
//  task
//
//  Created by TechReviews on 10/17/16.
//  Copyright © 2016 xtremer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

