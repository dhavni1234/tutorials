//
//  AlertController.h
//  taskView+Alert
//
//  Created by Raghu Bansal on 11/8/16.
//  Copyright © 2016 XtreemSolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlertController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *alertTitle;
@property (weak, nonatomic) IBOutlet UILabel *alertMessage;
@property (weak, nonatomic) NSString *titleString;
@property (weak, nonatomic) NSString *msgString;

+ (void)alertWithTitle:(NSString *)title andMessage:(NSString *)message delegate:(id)delegate alertButtonTitles:(NSArray *)buttons;


@end
